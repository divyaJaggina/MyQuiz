package com.example.harish.myquiz;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton radioButton,radioButton1;
    RadioGroup radioGroup,r2;
    boolean flag = false,flag1=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroup=findViewById(R.id.radbutton);
        r2=findViewById(R.id.radbutton1);
    }

    public void submit(View view)
    {
        int selectedId = radioGroup.getCheckedRadioButtonId();

      //  radioButton = (RadioButton) findViewById(R.id.maharashtra);
        radioButton = (RadioButton) findViewById(selectedId);
        if (selectedId==R.id.maharashtra) {
            if (flag == false)
            {
                flag = true;
                radioButton.setTextColor(Color.GREEN);
                Toast.makeText(this, "Correct Answer" + "\n" + "5 marks is added.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();
        } else  {
            radioButton.setTextColor(Color.RED);
            Toast.makeText(this, "Incorrect Answer " + "\n" + "Correct Answer is : Rajasthan", Toast.LENGTH_SHORT).show();
        }

    }

    public void submit1(View view)
    {
        int selectedId1 = r2.getCheckedRadioButtonId();

       // radioButton = (RadioButton) findViewById(R.id.maharashtra1);
        radioButton1 = (RadioButton) findViewById(selectedId1);
        if (selectedId1==R.id.maharashtra1) {
            if (flag1 == false)
            {
                flag1 = true;
                radioButton1.setTextColor(Color.GREEN);
                Toast.makeText(this, "Correct Answer" + "\n" + "5 marks is added.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();
        } else  {
            radioButton1.setTextColor(Color.RED);
            Toast.makeText(this, "Incorrect Answer " + "\n" + "Correct Answer is : Rajasthan", Toast.LENGTH_SHORT).show();
        }

        }
}
